@echo off

net session >nul 2>&1
if %errorlevel% neq 0 exit /b 1

set "KEY=HKLM\SOFTWARE\Policies\Microsoft\Windows\Safer\CodeIdentifiers"

reg add "%KEY%" /v DefaultLevel /t REG_DWORD /d 262144 /f
reg add "%KEY%" /v PolicyScope /t REG_DWORD /d 0 /f
reg add "%KEY%" /v TransparentEnabled /t REG_DWORD /d 1 /f

reg add "%KEY%\0\Paths\{11111111-1111-1111-1111-111111111111}" /v Description /t REG_SZ /d "Block VirtualBox.exe" /f
reg add "%KEY%\0\Paths\{11111111-1111-1111-1111-111111111111}" /v ItemData /t REG_SZ /d "%ProgramFiles%\Oracle\VirtualBox\VirtualBox.exe" /f
reg add "%KEY%\0\Paths\{11111111-1111-1111-1111-111111111111}" /v SaferFlags /t REG_DWORD /d 0 /f

reg add "%KEY%\0\Paths\{22222222-2222-2222-2222-222222222222}" /v Description /t REG_SZ /d "Block paths containing VirtualBox" /f
reg add "%KEY%\0\Paths\{22222222-2222-2222-2222-222222222222}" /v ItemData /t REG_SZ /d "*VirtualBox*" /f
reg add "%KEY%\0\Paths\{22222222-2222-2222-2222-222222222222}" /v SaferFlags /t REG_DWORD /d 0 /f

reg add "%KEY%\0\Paths\{33333333-3333-3333-3333-333333333333}" /v Description /t REG_SZ /d "Block VMware.exe" /f
reg add "%KEY%\0\Paths\{33333333-3333-3333-3333-333333333333}" /v ItemData /t REG_SZ /d "%ProgramFiles%\VMware\VMware Workstation" /f
reg add "%KEY%\0\Paths\{33333333-3333-3333-3333-333333333333}" /v SaferFlags /t REG_DWORD /d 0 /f

reg add "%KEY%\0\Paths\{44444444-4444-4444-4444-444444444444}" /v Description /t REG_SZ /d "Block paths containing VMware" /f
reg add "%KEY%\0\Paths\{44444444-4444-4444-4444-444444444444}" /v ItemData /t REG_SZ /d "*VMware*" /f
reg add "%KEY%\0\Paths\{44444444-4444-4444-4444-444444444444}" /v SaferFlags /t REG_DWORD /d 0 /f

gpupdate /force

exit